package lab10;

interface Figura {
    void desenhar();
}
