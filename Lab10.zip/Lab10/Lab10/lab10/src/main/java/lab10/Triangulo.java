package lab10;

public class Triangulo implements Figura {
    private static Triangulo trianguloIsosceles = null;
    private static Triangulo trianguloEquilatero = null;
    private static Triangulo trianguloRetangulo = null;
    
    private String tipo;

    private Triangulo(String tipo) {
        this.tipo = tipo;
    }

    public static Triangulo getInstance(String tipo) {
        if (tipo.equalsIgnoreCase("isosceles")) {
            if (trianguloIsosceles == null) {
                trianguloIsosceles = new Triangulo("Isósceles");
            }
            return trianguloIsosceles;
        } else if (tipo.equalsIgnoreCase("equilatero")) {
            if (trianguloEquilatero == null) {
                trianguloEquilatero = new Triangulo("Equilátero");
            }
            return trianguloEquilatero;
        } else if (tipo.equalsIgnoreCase("retangulo")) {
            if (trianguloRetangulo == null) {
                trianguloRetangulo = new Triangulo("Retângulo");
            }
            return trianguloRetangulo;
        } else {
            throw new IllegalArgumentException("Tipo de triângulo desconhecido.");
        }
    }

    @Override
    public void desenhar() {
        System.out.println("Desenhando um triângulo " + tipo + ".");
    }
}
