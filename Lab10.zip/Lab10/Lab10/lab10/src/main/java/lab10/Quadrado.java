package lab10;

public class Quadrado implements Figura {
    @Override
    public void desenhar() {
        System.out.println("Desenhando um quadrado.");
    }
}
