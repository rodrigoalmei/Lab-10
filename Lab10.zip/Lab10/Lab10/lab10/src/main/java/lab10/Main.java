package lab10;

public class Main {
    public static void main(String[] args) {
        // Obtendo a instância única de Circulo
        Figura circulo = Circulo.getInstance();
        circulo.desenhar();

        // Obtendo as instâncias únicas dos triângulos
        Figura trianguloIsosceles = Triangulo.getInstance("isosceles");
        trianguloIsosceles.desenhar();

        Figura trianguloEquilatero = Triangulo.getInstance("equilatero");
        trianguloEquilatero.desenhar();

        Figura trianguloRetangulo = Triangulo.getInstance("retangulo");
        trianguloRetangulo.desenhar();

        // Criando múltiplos quadrados
        Figura quadrado1 = new Quadrado();
        quadrado1.desenhar();

        Figura quadrado2 = new Quadrado();
        quadrado2.desenhar();
    }
}
