package lab10;

public class Circulo implements Figura {
    private static Circulo instanciaUnica = null;

    public Circulo() {}

    public static Circulo getInstance() {
        if (instanciaUnica == null) {
            instanciaUnica = new Circulo();
        }
        return instanciaUnica;
    }

    @Override
    public void desenhar() {
        System.out.println("Desenhando um círculo.");
    }
}
