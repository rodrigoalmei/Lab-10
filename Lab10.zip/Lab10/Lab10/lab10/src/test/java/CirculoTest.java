import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertSame;
import org.junit.jupiter.api.Test;

import lab10.Circulo;

class CirculoTest {

    @Test
    void testSingletonInstance() {
        
        Circulo instance1 = Circulo.getInstance();
        Circulo instance2 = Circulo.getInstance();

        // Verifica se as instâncias são iguais (Singleton)
        assertSame(instance1, instance2, "Deveria retornar a mesma instância.");
    }

    @Test
    void testDesenharMethod() {
        
        Circulo instance = Circulo.getInstance();

        // Executa o método desenhar para verificar se não lança nenhuma exceção
        assertDoesNotThrow(instance::desenhar, "O método desenhar não deveria lançar exceções.");
    }
}
