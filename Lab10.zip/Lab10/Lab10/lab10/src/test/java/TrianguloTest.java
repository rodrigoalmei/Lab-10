import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.assertSame;
import org.junit.jupiter.api.Test;

import lab10.Triangulo;

class TrianguloTest {

    @Test
    void testTrianguloSingleton() throws Exception {
        // Acessando o método privado getInstance() da classe Triangulo usando reflexão
        Method method = Triangulo.class.getDeclaredMethod("getInstance", String.class);
        method.setAccessible(true); // Torna o método acessível

        // Invocando o método para criar instâncias dos diferentes tipos de Triângulo
        Triangulo trianguloIsosceles1 = (Triangulo) method.invoke(null, "isosceles");
        Triangulo trianguloIsosceles2 = (Triangulo) method.invoke(null, "isosceles");

        Triangulo trianguloEquilatero1 = (Triangulo) method.invoke(null, "equilatero");
        Triangulo trianguloEquilatero2 = (Triangulo) method.invoke(null, "equilatero");

        Triangulo trianguloRetangulo1 = (Triangulo) method.invoke(null, "retangulo");
        Triangulo trianguloRetangulo2 = (Triangulo) method.invoke(null, "retangulo");

        // Verifica se as instâncias dos triângulos são iguais
        assertSame(trianguloIsosceles1, trianguloIsosceles2, "As instâncias de Triângulo Isósceles devem ser iguais.");
        assertSame(trianguloEquilatero1, trianguloEquilatero2, "As instâncias de Triângulo Equilátero devem ser iguais.");
        assertSame(trianguloRetangulo1, trianguloRetangulo2, "As instâncias de Triângulo Retângulo devem ser iguais.");
    }
}
