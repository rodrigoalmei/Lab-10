import static org.junit.jupiter.api.Assertions.assertNotSame;
import org.junit.jupiter.api.Test;

import lab10.Quadrado;

class QuadradoTest {

    @Test
    void testQuadradoIndependentes() {
        Quadrado quadrado1 = new Quadrado();
        Quadrado quadrado2 = new Quadrado();
        assertNotSame(quadrado1, quadrado2, "As instâncias de Quadrado devem ser diferentes.");
    }
}
